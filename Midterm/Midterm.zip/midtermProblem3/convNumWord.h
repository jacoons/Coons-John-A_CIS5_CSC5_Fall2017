/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   convNumWord.h
 * Author: Andrew
 *
 * Created on October 27, 2017, 8:22 PM
 */

#ifndef CONVNUMWORD_H
#define CONVNUMWORD_H

class convNumWord {
public:
    convNumWord();
    convNumWord(const convNumWord& orig);
    virtual ~convNumWord();
private:

};

#endif /* CONVNUMWORD_H */


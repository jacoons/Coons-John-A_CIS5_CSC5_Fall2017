/* 
 * Author: Coons, John A.
 * Created on November 1st, 2017, 1:52 pM
 * Purpose:  Project 1 - Simulate the card game "War".
 *           No Global Variables, No Doubles
 *           7 Character or less variable names
 */

//System Libraries

#include <iostream>     //Input - Output Library
#include <string>       //Strings
#include <algorithm>    //To use transform
#include "Card.h"       //Custom class to create card value and display
#include "Deck.h"       //Custom class to shuffle, deal and display the deck
#include <iomanip>      //Text formatting
#include <fstream>      //File in/out

using namespace std;    //Name-space under which system libraries exist

//User Libraries 

//Function Prototypes 




void game(Deck deck1) {
	
	bool play = true;
	while (play) {
            
        cout<<fixed<<setprecision(2);
        
        ofstream out_data("errorLog.dat");
                
		cout << "There are " << deck1.cardsLeft() << " cards remaining"
                        " in the deck." << endl;
		cout << "Your card is: " << endl;
		Card player1 = deck1.deal();
		player1.display();
		cout << "My card is: " << endl;
		Card player2 = deck1.deal();
		player2.display();

		if (player1.getValue() > player2.getValue()) {
                        int win = player1.getValue() - player2.getValue();
                        cout << "You win by a margin of "<<static_cast<float>(win)
                                <<"!!!"<<endl;
                        
                       		}
                
                
		else if (player1.getValue() < player2.getValue()) {
                        int lose = player2.getValue() - player1.getValue();
                        cout << "You lose by a margin of "<<static_cast<float>(lose)
                                <<"!!!"<<endl;
                                
					}
		else {
			cout << "Just like kissing cousins." << endl;
		}

		cout << endl << "One more time? (yes/no)" << endl;
		string cont;
		cin >> cont;
		transform(cont.begin(), cont.end(), cont.begin(), ::tolower);

		string aa = "yes";
		string bb = "no";

		if (cont == aa) {
			play = true;
			if (deck1.cardsLeft() == 0) {
				cout << "No cards remaining!!!" << endl
					<< "We hope to see you soon!" << endl;
				play = false;
			}
		}
		else if (cont == bb) {
			play = false;
			cout << endl << "We hope to see you soon!" << endl;
		}
		else if (cont != aa || cont != bb) {
			cout << "Invalid input" << endl;
                        out_data<<"ERROR OCCURED: INVALID ENTRY!"<<endl;
			bool invalid = true;
			while (invalid) {
				cin >> cont;
				if (cont == aa) {
					invalid = false;
				}
				else if (cont == bb) {
					invalid = false;
					play = false;
					cout << "We hope to see you soon!" << endl;
				}
			}
		}

	}
}

//game menu
void menu() {
    {
 
        cout << "Get ready to play War!\n" << endl;
	cout << "1)	Reset the deck." << endl;
	cout << "2)	Display remaining cards." << endl;
	cout << "3)	Shuffle." << endl;
	cout << "4)	Play." << endl;
	cout << "5)	Exit." << endl;
        cout << "i)      Instructions." <<endl;
        }
}//end menu method

//main class 
int main() {
        
        //declare variables
	int sel;
	bool stay = true;
       
        
             
        
	Deck deck1;

        
        
	while (stay) {
		menu();
		cin >> sel;
                            
                      
                  
		switch (sel) {
		case 1:
			cout << "The deck has been reset." << endl;
			break;
		case 2:
			deck1.displayDeck();
			break;
		case 3:
			deck1.shuffle();
			deck1.displayDeck();
			break;
		case 4:
			game(deck1);
			break;
		case 5:
			cout << "\nWe hope to see you soon!" << endl;
			stay = false;
			break;
                           
		}
                 
	}


	return 0;
}//end main





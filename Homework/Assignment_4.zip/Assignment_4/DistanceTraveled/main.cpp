#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    

    int mph, hours;
    
    cout<<"What is the speed of your vehicle in Miles per Hour (MPH)? ";
    cin>> mph;
    
    cout<<"How many hours have you traveled? ";
    cin>> hours;
    
    cout<<"HOURS\t\tDistance Traveled"<<endl;
    cout<<"--------------------------------------"<<endl;
    
    for (int hour =1; hour <= hours; hour++)
    {    
        
        int distance = mph + distance;
        cout<<hour<<" \t\t  "<<distance<<endl;
      
        
    }    
   
    
            
            
    
    
    
    

    return 0;
}


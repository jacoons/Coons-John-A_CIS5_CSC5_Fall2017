#include <iostream>

using namespace std;

int main()
{
    cout<<"Coons, John A."<<endl;
    cout<<"ADDRESS Riverside,CA"<<endl;
    cout<<"951-218-6113"<<endl;
    cout<<"Electrical Engineer"<<endl;
    
    return 0;
}
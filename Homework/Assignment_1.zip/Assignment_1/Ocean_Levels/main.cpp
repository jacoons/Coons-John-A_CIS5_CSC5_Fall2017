
#include <iostream>

using namespace std;

int main()
{
    float ocean_level = 1.5;
    
    cout<<"The ocean's current level is "<<ocean_level<<" millimeters."<<endl;
    cout<<"In 5 years the level will be "<<(ocean_level*5)<<" millimeters."<<endl;
    cout<<"In 5 years the level will be "<<(ocean_level*7)<<" millimeters."<<endl;
    cout<<"In 5 years the level will be "<<(ocean_level*10)<<" millimeters."<<endl;
    
    
    return 0;
}


#include <iostream>

using namespace std;

int main()
{
    short number_1, number_2, total;
    
    number_1=50;
    number_2=100;
    total=number_1+number_2;
        
    cout<<"The sum of the two numbers is "<<total<<".";
    
    return 0;
}


#include <iostream>

using namespace std;

int main()
{
    short mpg, miles, tank;
    
    miles=375;
    tank=13;
    mpg=miles/tank;
    
    cout<<"The car gets "<<(mpg)<<" miles per gallon.";
                
    

    return 0;
}

